Sup Language Support
====================

Syntax highlighting for `.sup` files.

Package
-------

Install Node.js, then:
```
npm i -g @vscode/vsce
cd vscode-extension
vsce package
```
This produces a `.vsix` that you can install in VS Code via Extensions → "Install from VSIX".

