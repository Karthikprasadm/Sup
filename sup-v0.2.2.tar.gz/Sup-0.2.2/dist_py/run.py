from m_06_mixed import __main__ as _m

if __name__ == '__main__':
    _m()
