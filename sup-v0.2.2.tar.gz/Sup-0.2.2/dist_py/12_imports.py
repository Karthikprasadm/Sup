# Transpiled from sup
from sys import stdout


def __main__():
    import mathlib
    print(mathlib.pi)
    print(mathlib.square(7))
    from mathlib import square
    print(square(3))

if __name__ == '__main__':
    __main__()
